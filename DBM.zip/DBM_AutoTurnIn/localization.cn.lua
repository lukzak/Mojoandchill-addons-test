﻿-- ------------------------------------------- --
--   Deadly Boss Mods - Chinese localization   --
--    by Diablohu<白银之手> @ 二区-轻风之语    --
--             www.dreamgen.net                --
--                 1/8/2007                    --
-- ------------------------------------------- --

if (GetLocale() == "zhCN") then
--Runecloth
	DBM_RUNECLOTH_NAME         = "符文布";
	DBM_RUNECLOTH_DESCRIPTION  = "自动上交符文布";
	DBM_RAEDONDUSKSTRIKER      = "莱顿·暗影";
	DBM_CLAVICUSKNAVINGHAM     = "克拉维斯·纳文哈姆";
	DBM_BUBULOACERBUS          = "巴巴罗·阿克巴斯";
	DBM_MISTINASTEELSHIELD     = "米斯蒂娜·钢盾";
	DBM_RUNECLOTH_THANKS       = "感谢您使用 Deadly BossMods！";


--Timbermaw
	DBM_TIMBERMAW_NAME			= "木喉要塞"
	DBM_TIMBERMAW_WS_NAME		= "冬泉灵魂珠串";
	DBM_TIMBERMAW_FW_NAME		= "死木头饰羽毛";
	DBM_TIMBERMAW_DESCRIPTION 	= "自动上交木喉要塞声望物品";
	DBM_TIMBERMAW_THANKS     	= "感谢您使用 Deadly BossMods！";
	DBM_SALFA    				= "萨尔法";
	DBM_NAFIEN    				= "纳菲恩";
	DBM_GRAZLE    				= "格拉兹";

end
