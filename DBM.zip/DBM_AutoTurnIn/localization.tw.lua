﻿if (GetLocale() == "zhTW") then

--Runecloth
DBM_RUNECLOTH_NAME         = "符文布";
DBM_RUNECLOTH_DESCRIPTION  = "允許自動繳交符文布.";
DBM_RAEDONDUSKSTRIKER      = "萊頓·暗影";
DBM_CLAVICUSKNAVINGHAM     = "克拉維斯·納文哈姆";
DBM_BUBULOACERBUS          = "巴巴羅·阿克巴斯";
DBM_MISTINASTEELSHIELD     = "米斯蒂娜·鋼盾";
DBM_RUNECLOTH_THANKS       = "感謝您使用 La Vendetta Boss Mods!";

end
