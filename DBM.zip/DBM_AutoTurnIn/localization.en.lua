--Runecloth
DBM_RUNECLOTH_NAME         = "Runecloth";
DBM_RUNECLOTH_DESCRIPTION  = "Allows auto turn in of Runecloth.";
DBM_RAEDONDUSKSTRIKER      = "Raedon Duskstriker";
DBM_CLAVICUSKNAVINGHAM     = "Clavicus Knavingham";
DBM_BUBULOACERBUS          = "Bubulo Acerbus";
DBM_MISTINASTEELSHIELD     = "Mistina Steelshield";
DBM_RUNECLOTH_THANKS       = "Thanks for using La Vendetta Boss Mods!";


--Timbermaw
DBM_TIMBERMAW_NAME			= "Timbermaw Hold	"
DBM_TIMBERMAW_WS_NAME		= "Winterfall Spirit Beads";
DBM_TIMBERMAW_FW_NAME		= "Deadwood Headdress Feather";
DBM_TIMBERMAW_DESCRIPTION  = "Allows auto turn in of rep items for Timbermaw Hold.";
DBM_TIMBERMAW_THANKS       = "Thanks for using La Vendetta Boss Mods!";
DBM_SALFA    				= "Salfa";
DBM_NAFIEN    				= "Nafien";
DBM_GRAZLE    				= "Grazle";
