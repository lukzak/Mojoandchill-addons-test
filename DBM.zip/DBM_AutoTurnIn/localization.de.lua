﻿-- http://www.allegro-c.de/unicode/zcodes.htm
--


if (GetLocale()=="deDE") then

		
	--Runenstoff (Translation by Sadie)
	DBM_RUNECLOTH_NAME = "Runenstoff";
	DBM_RUNECLOTH_DESCRIPTION = "Ermöglicht automatisches Spenden von Runenstoff.";
	DBM_RAEDONDUSKSTRIKER = "Raedon Duskstriker";
	DBM_CLAVICUSKNAVINGHAM = "Clavicus Knavingham";
	DBM_BUBULOACERBUS = "Bubulo Acerbus";
	DBM_MISTINASTEELSHIELD = "Mistina Steelshield";
	DBM_RUNECLOTH_THANKS = "Danke f\195\188r das Benutzen der La Vendetta Boss Mods!";
end
