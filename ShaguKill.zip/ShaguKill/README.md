# ShaguKill

Displays the count of remaining kills or other Exp-giving events that are required to gain the next levelup.


![screenshot](https://raw.githubusercontent.com/shagu/ShaguAddons/master/_img/ShaguKill/screenshot.jpg)

## Installation
1. Download **[Latest Version](https://github.com/shagu/ShaguKill/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "ShaguKill-master" to "ShaguKill"
4. Copy "ShaguKill" into Wow-Directory\Interface\AddOns
5. Restart Wow