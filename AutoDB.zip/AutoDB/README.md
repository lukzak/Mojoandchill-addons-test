# AutoDB
A 1.12.1 Vanilla WoW addon that automatically does /db chests and /db rares for pfQuest users.

Install location should be: ..\Interface\AddOns\AutoDB

**Make sure you remove the "-main" from the "AutoDB-main" folder so it becomes just "AutoDB"**

_99% of this addon's code by Trckster. They've given me permission to upload this version of it._
