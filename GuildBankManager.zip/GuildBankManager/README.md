# GuildBankManager_AddOn
GBM AddOn (Classic WoW 1.12.1)

Alle Informationen über dieses Projekt können im GitHub-Wiki gefunden werden:

https://github.com/sigmaroot/GuildBankManager_AddOn/wiki
