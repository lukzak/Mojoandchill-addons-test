local achievements = {}

do -- notification library
  achievements.window = {}
  achievements.max_window = 5

  local addonpath = "Interface\\AddOns\\HFAchievements"

  function achievements:CreateFrame()
    local frame = CreateFrame("Button", "Achievment", UIParent)

    frame:SetWidth(300)
    frame:SetHeight(88)
    frame:SetFrameStrata("DIALOG")
    frame:Hide()

    do -- animations
      frame:SetScript("OnClick", function()
        this:Hide()
      end)

      frame:SetScript("OnShow", function()
        this.modifyA = 1
        this.modifyB = 0
        this.stateA = 0
        this.stateB = 0
        this.animate = true

        this.showTime = GetTime()
      end)

      frame:SetScript("OnUpdate", function()
        local fps = GetFramerate()

        if this.animate == true then
          if this.stateA > .33 and this.modifyA == 1 then
            this.modifyB = 1
          end

          if this.stateA > .66 then
            this.modifyA = -1
          end

          if this.stateB > .5 then
            this.modifyB = -1
          end

          this.stateA = this.stateA + this.modifyA/fps
          this.stateB = this.stateB + this.modifyB/fps

          this.glow:SetGradientAlpha("HORIZONTAL",
            this.stateA, this.stateA, this.stateA, this.stateA,
            this.stateB, this.stateB, this.stateB, this.stateB)

          this.shine:SetGradientAlpha("VERTICAL",
            this.stateA, this.stateA, this.stateA, this.stateA,
            this.stateB, this.stateB, this.stateB, this.stateB)

          if this.stateA < 0 and this.stateB < 0 then
            this.animate = false
          end
        end

        if this.showTime + 5 < GetTime() then
          this:SetAlpha(this:GetAlpha() - 1/fps)
          if this:GetAlpha() <= 0 then
            this:Hide()
            this:SetAlpha(1)
          end
        end
      end)
    end

    frame.background = frame:CreateTexture("background", "BACKGROUND")
    frame.background:SetTexture(addonpath .. "\\textures\\UI-Achievement-Alert-Background")
    frame.background:SetPoint("TOPLEFT", 0, 0)
    frame.background:SetPoint("BOTTOMRIGHT", 0, 0)
    frame.background:SetTexCoord(0, .605, 0, .703)

    frame.unlocked = frame:CreateFontString("Unlocked", "DIALOG", "GameFontBlack")
    frame.unlocked:SetWidth(200)
    frame.unlocked:SetHeight(12)
    frame.unlocked:SetPoint("TOP", 7, -23)
    frame.unlocked:SetText(COMPLETE)

    frame.name = frame:CreateFontString("Name", "DIALOG", "GameFontHighlight")
    frame.name:SetWidth(240)
    frame.name:SetHeight(16)
    frame.name:SetPoint("BOTTOMLEFT", 72, 36)
    frame.name:SetPoint("BOTTOMRIGHT", -60, 36)

    frame.glow = frame:CreateTexture("glow", "OVERLAY")
    frame.glow:SetTexture(addonpath .. "\\textures\\UI-Achievement-Alert-Glow")
    frame.glow:SetBlendMode("ADD")
    frame.glow:SetWidth(400)
    frame.glow:SetHeight(171)
    frame.glow:SetPoint("CENTER", 0, 0)
    frame.glow:SetTexCoord(0, 0.78125, 0, 0.66796875)
    frame.glow:SetAlpha(0)

    frame.shine = frame:CreateTexture("shine", "OVERLAY")
    frame.shine:SetBlendMode("ADD")
    frame.shine:SetTexture(addonpath .. "\\textures\\UI-Achievement-Alert-Glow")
    frame.shine:SetWidth(67)
    frame.shine:SetHeight(72)
    frame.shine:SetPoint("BOTTOMLEFT", 0, 8)
    frame.shine:SetTexCoord(0.78125, 0.912109375, 0, 0.28125)
    frame.shine:SetAlpha(0)

    frame.icon = CreateFrame("Frame", "icon", frame)
    frame.icon:SetWidth(124)
    frame.icon:SetHeight(124)
    frame.icon:SetPoint("TOPLEFT", -26, 16)

    frame.icon.bling = frame.icon:CreateTexture("bling", "BORDER")
    frame.icon.bling:SetTexture(addonpath .. "\\textures\\UI-Achievement-Bling")
    frame.icon.bling:SetPoint("CENTER", -1, 1)
    frame.icon.bling:SetWidth(116)
    frame.icon.bling:SetHeight(116)

    frame.icon.texture = frame.icon:CreateTexture("texture", "ARTWORK")
    frame.icon.texture:SetPoint("CENTER", 0, 3)
    frame.icon.texture:SetWidth(50)
    frame.icon.texture:SetHeight(50)

    frame.icon.overlay = frame.icon:CreateTexture("overlay", "OVERLAY")
    frame.icon.overlay:SetTexture(addonpath .. "\\textures\\UI-Achievement-IconFrame")
    frame.icon.overlay:SetPoint("CENTER", -1, 2)
    frame.icon.overlay:SetHeight(72)
    frame.icon.overlay:SetWidth(72)
    frame.icon.overlay:SetTexCoord(0, 0.5625, 0, 0.5625)

    frame.shield = CreateFrame("Frame", "shield", frame)
    frame.shield:SetWidth(64)
    frame.shield:SetHeight(64)
    frame.shield:SetPoint("TOPRIGHT", -10, -13)

    frame.shield.icon = frame.shield:CreateTexture("icon", "BACKGROUND")
    frame.shield.icon:SetTexture(addonpath .. "\\textures\\UI-Achievement-Shields")
    frame.shield.icon:SetWidth(52)
    frame.shield.icon:SetHeight(48)
    frame.shield.icon:SetPoint("TOPRIGHT", 1, -8)

    frame.shield.points = frame.shield:CreateFontString("Name", "DIALOG", "GameFontWhite")
    frame.shield.points:SetPoint("CENTER", 7, 2)
    frame.shield.points:SetWidth(64)
    frame.shield.points:SetHeight(64)

    return frame
  end

  function achievements:ShowPopup(text, points, icon, elite, header)
    for i=1, achievements.max_window do
      if not achievements.window[i]:IsVisible() then
        achievements.window[i].unlocked:SetText(header or COMPLETE)
        achievements.window[i].name:SetText(text or "DUMMY")
        achievements.window[i].icon.texture:SetTexture(icon or "Interface\\QuestFrame\\UI-QuestLog-BookIcon")

        if elite then
          achievements.window[i].shield.icon:SetTexCoord(0, .5 , .5 , 1)
        else
          achievements.window[i].shield.icon:SetTexCoord(0, .5 , 0 , .5)
        end

        achievements.window[i].shield.points:SetText(points or "10")
        achievements.window[i]:Show()

        return
      end
    end
  end

  for i=1, achievements.max_window do
    achievements.window[i] = achievements:CreateFrame()
    achievements.window[i]:SetPoint("BOTTOM", 0, 28 + (100*i))
  end
end

do -- trigger
  local trigger = CreateFrame("Frame")
  trigger:RegisterEvent("CHAT_MSG_ADDON")
  trigger:SetScript("OnEvent", function()
    -- abort on non-achievement or invalid messages
    if not arg1 then return end
    if not arg2 then return end
    if arg1 ~= "HATEFORGE_ACHIEVEMENT" then return end
    if arg4 ~= UnitName("player") then return end

    -- read the message
    local _, _, icon, points, title, header = string.find(arg2, "(.+):(.+):(.+):(.+)")

    -- abort on unknown strings
    if not icon or not points or not title or not header then return end
    icon = "Interface\\Icons\\" .. icon
    achievements:ShowPopup(title, points, icon, nil, header)
  end)
end
