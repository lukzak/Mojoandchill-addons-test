# /stopcasting

`/stopcasting` will interrupt your current spell.

## Examples

```lua
/stopcasting
/cast [@mouseover] Flash Heal
```

You will interrupt your current cast and cast Flash Heal at your mouseover
target instead.