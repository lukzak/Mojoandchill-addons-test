# /petattack

`/petattack` makes your pet attack.

## Examples

```lua
/petattack [@focus]
```
You pet will attack your focus target (Refer to the [Compatibility Notes](/../compatibility.md)).

---

```lua
/petattack [@mouseover harm nodead]
```
Your pet will attack your mouseover target if it is attackable and not dead.