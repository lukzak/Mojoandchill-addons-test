# /rl

`/rl` tells the client to reload all Addons. This is mainly used for debugging.