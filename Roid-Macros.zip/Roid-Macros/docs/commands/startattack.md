# /startattack

`/startattack` will make you attack with your melee weapons. Spammable.

## Examples

```lua
/startattack
/cast Heroic Strike
```

You will start attacking and cast Heroic Strike whenever it is ready.
