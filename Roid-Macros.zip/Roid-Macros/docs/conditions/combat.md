# combat / nocombat

May only be used in combat. Can be inverted by adding `no` in front of `combat`.

## Example:

```lua
/cast [nocombat] Starfire; Wrath
```

Your Oomkin will cast Starfire when you are not in combat and Wrath once you are.
