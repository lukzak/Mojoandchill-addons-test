# channeled / nochanneled

This condition will only fire when you currently are [not] casting any
channeled spells.

## Examples

```lua
/cast [nochanneled] Shadow Bolt
```

You will cast Shadow Bolt whenever you're not casting any channeled spells.
