# The #showtooltip instruction

You can re-enable tooltips using the #showtooltip [item name or spell name]
instruction.

## Examples

```lua
#showtooltip Cone of Cold(Rank 1)
/cast [mypower>200] Cone of Cold(Rank 1)
```

```lua
#showtooltip  Mish'undare, Circlet of the Mind Flayer
/use Linen Bandage
```
