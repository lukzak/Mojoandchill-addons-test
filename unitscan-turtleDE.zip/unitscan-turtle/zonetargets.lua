function unitscan_zone_targets()
	local zone = GetZoneText()
	if not zone then return end

    unitscan_zonetargets = {} -- reset zonetargets
    local t = unitscan_zonetargets
    
	if zone == "Alteracgebirge" then
		t["Araga"] = true
        t["Cranky Benj"] = true
        t["Gravis Galgenknoten"] = true
        t["Jimmy der Bluter"] = true
        t["Lo'Grosh"] = true
        t["Skhowl"] = true
        t["Steinwüter"] = true
        t["Narillasanz"] = true

    elseif zone == "Arathihochland" then
        t["Faulbauch"] = true
        t["Geomant Flintdolch"] = true
        t["Kovork"] = true
        t["Molok der Zermalmer"] = true
        t["Darbel Montrose"] = true
        t["Nimar der Töter "] = true
        t["Prinz Nazjak"] = true
        t["Ruul Zweistein"] = true
        t["Singer"] = true
        t["Zalas Witherbark"] = true

    elseif zone == "Ashenvale" then
        t["Akkrilus"] = true
        t["Apotheker Falthis"] = true
        t["Astschnapper"] = true
        t["Eck'alom"] = true
        t["Lady Vespia"] = true
        t["Nebelheuler"] = true
        t["Muggelflosse"] = true
        t["Knurrtatze"] = true
        t["Prinz Schleifer"] = true
        t["Grummelkehle"] = true
        t["Terrowulf-Rudelführer"] = true
        t["Ursol'lok"] = true
        t["Wandernder Beschützer"] = true

    elseif zone == "Azshara" then
        t["Antilos"] = true
        t["Knochenhexe"] = true
        t["Torhüter Donnerschrei"] = true
        t["General Fangferror"] = true
        t["Lady Sesspira"] = true
        t["Magister Falkhelm"] = true
        t["Meister Gräuelbart"] = true
        t["Monnos der Älteste"] = true
        t["Schuppenbart"] = true
        t["Geist der Verdammten"] = true
        t["Evalcharr"] = true
        t["Varo'thens Geist"] = true

    elseif zone == "Ödland" then
        t["7:XT"] = true
        t["Anathemus"] = true
        t["Zerbrochener Zahn"] = true
        t["Rumpler"] = true
        t["Kommandant der Schattenschmiede"] = true
        t["Belagerungsgolem"] = true
        t["Kriegsgolem"] = true
        t["Zaricotl"] = true

    elseif zone == "Blackrocktiefen" then
        t["Panzor der Unbesiegbare"] = true
        t["Pyromant Weiskorn"] = true

    elseif zone == "Blackrockspitze" then
        t["Bannok Grimmaxt"] = true
        t["Brennende Teufelswache"] = true
        t["Kristallfangzahn"] = true
        t["Ghok Haudrauf"] = true
        t["Jed Runenblick"] = true
        t["Rüstmeister Zigris"] = true
        t["Kampflord der Felsspitzoger"] = true
        t["Metzger der Felsspitzoger"] = true
        t["Maguslord der Felsspitzoger"] = true
        t["Urok Schreckensbote"] = true

    elseif zone == "Verwüstete Lande" then
        t["Akubar der Seher"] = true
        t["Clack der Häscher"] = true
        t["Todesauge"] = true
        t["Mutreich"] = true
        t["Suhlaman"] = true
        t["Magronos der Unerschütterliche"] = true
        t["Mojo der Verwachsene"] = true
        t["Verheerer"] = true
        t["Fledderschnabel"] = true
        t["Knochenhexe"] = true
        t["Geist der Verdammten"] = true

    elseif zone == "Brennende Steppe" then
        t["Knochenhexe"] = true
        t["Totenreißer"] = true
        t["Gorgon'och"] = true
        t["Gruklash"] = true
        t["Hahk'Zor"] = true
        t["Hematos"] = true
        t["Fehlfunktionierender Häscher"] = true
        t["Geist der Verdammten"] = true
        t["Terrorstifter"] = true
        t["Thauris Balgarr"] = true
        t["Volchan"] = true

    elseif zone == "Dunkelküste" then
        t["Carnivous der Zerstörer"] = true
        t["Feuerrufer Radison"] = true
        t["Platsch der Grausame"] = true
        t["Lady Mondblick"] = true
        t["Lady Vespira"] = true
        t["Licillin"] = true
        t["Lord Sündenbrecher"] = true
        t["Schattenklaue"] = true
        t["Schreitergelegemutter"] = true

    elseif zone == "Desolace" then
        t["Verfluchter der Zackenkämme"] = true
        t["Verfluchter Zentaur"] = true
        t["Kicherer"] = true
        t["Hissperak"] = true
        t["Kaskk"] = true
        t["Prinz Kellen"] = true

    elseif zone == "Dun Morogh" then
        t["Ben"] = true
        t["Bjarn"] = true
        t["Edan der Heuler"] = true
        t["Gibblewilt"] = true
        t["Altvater Arctikus"] = true
        t["Hammerbuckel"] = true
        t["Holzplanke"] = true

    elseif zone == "Durotar" then
        t["Captain Stumpfhauer"] = true
        t["Todesschinder"] = true
        t["Höllenwirker Hoohn"] = true
        t["Geolord Mottle"] = true
        t["Kriegsherr Kolkanis"] = true
        t["Wachkommandant Zalaphil"] = true

    elseif zone == "Dämmerwald" then
        t["Lord Malathrom"] = true
        t["Lupos"] = true
        t["Lurking Shadow"] = true
        t["Mor'Ladim"] = true
        t["Naraxis"] = true
        t["Nefaru"] = true
        t["Kleiner"] = true

    elseif zone == "Marschen von Dustwallow" then
        t["Brimgore"] = true
        t["Schwarzauge"] = true
        t["Korallenhai"] = true
        t["Graunebelwitwe"] = true
        t["Dart"] = true
        t["Drogoth der Wanderer"] = true
        t["Hayoc"] = true
        t["Lord Angler"] = true
        t["Brühschlammerwurm"] = true
        t["Reißerschuppe"] = true
        t["Der Faulende"] = true
        
    elseif zone == "Östliche Pestländer" then
        t["Knochenhexe"] = true
        t["Todessprecher Selendre"] = true
        t["Duggan Wildhammer"] = true
        t["Gefallener Held"] = true
        t["Gish der Unbewegliche"] = true
        t["Hed'mush der Faulende"] = true
        t["Hochgeneral Abbendis"] = true
        t["Lord Finstersense"] = true
        t["Waldläuferlord Falkenspeer"] = true
        t["Geist der Verdammten"] = true
        t["Kriegsherr Thresh'jin"] = true
        t["Zul'Brin Wirbelstab"] = true

    elseif zone == "Wald von Elwynn" then
        t["Fedfennel"] = true
        t["Gruff Swiftbite"] = true
        t["Morgaine die Verschlagene"] = true
        t["Giftzahnbrutmutter"] = true
        t["Narg der Zuchtmeister"] = true
        t["Thuros Lightfingers"] = true

    elseif zone == "Teufelswald" then
        t["Alshirr Teufelsodem"] = true
        t["Todesheuler"] = true
        t["Dessecus"] = true
        t["Korruptus"] = true
        t["Mongress"] = true
        t["Olm der Weise"] = true
        t["Wutpranke"] = true
        t["Der Ongar"] = true
        
    elseif zone == "Feralas" then
        t["Antilus der Aufsteiger"] = true
        t["Arash-ethis"] = true
        t["Blutschrei der Pirscher"] = true
        t["Diamantenkopf"] = true
        t["Laubbruder Knarz"] = true
        t["Grug'thok the Seer"] = true
        t["Lady Szallah"] = true
        t["Mushgog"] = true
        t["Silbergrimm der Weise"] = true
        t["Qirot"] = true
        t["Skarr der Unbezwingbare"] = true
        t["Knurrer"] = true
        t["Der Razza"] = true

    elseif zone == "Gnomeregan" then
        t["Botschafter der Dunkeleisenzwerge"] = true

    elseif zone == "Vorgebirge von Hillsbrad" then
        t["Samras"] = true
        t["Kriechfänger"] = true
        t["Lady Zephris"] = true
        t["Narillasanz"] = true
        t["Ro'Bark"] = true
        t["Narbenflosse"] = true
        t["Tamra Stormpike"] = true

    elseif zone == "Ironforge" then
        t["Spektraler Pirscher"] = true

    elseif zone == "Loch Modan" then
        t["Boss Galgosh"] = true
        t["Grubenmeister Schaufelphlansch"] = true
        t["Emogg der Zermalmer"] = true
        t["Gradok"] = true
        t["Grizlak"] = true
        t["Haren Swifthoof"] = true
        t["Großer Lochkrokilisk"] = true
        t["Lord Condar"] = true
        t["Magosh"] = true
        t["Old Sooty"] = true
        t["Shanda die Weberin"] = true
        t["Thragomm"] = true

    elseif zone == "Maraudon" then
        t["Meshlok der Ernter"] = true

    elseif zone == "Mulgore" then
        t["Vollstrecker Emilgund"] = true
        t["Geistheuler"] = true
        t["Mazzranache"] = true
        t["Schwester Hasspeitsche"] = true
        t["Stummelspeer"] = true
        t["Der Kratzer"] = true

    elseif zone == "Orgrimmar" then
        t["Spektraler Pirscher"] = true

    elseif zone == "Der Kral von Razorfen" then
        t["Blinder Jäger"] = true
        t["Erdenrufer Halmgar"] = true
        t["Speerbalg von Razorfen"] = true

    elseif zone == "Rotkammgebirge" then
        t["Felsenherz"] = true
        t["Chatter"] = true
        t["Kazon"] = true
        t["Lurking Shadow"] = true
        t["Rippenbrecher"] = true
        t["Rohh der Schweigsame"] = true
        t["Sucher Aqualon"] = true
        t["Fletschzahn"] = true
        t["Kalmarrik"] = true
        t["Volchan"] = true

    elseif zone == "Das scharlachrote Kloster" then
        t["Azshir der Schlaflose"] = true
        t["Gestürzter Held"] = true
        t["Eisenrücken"] = true

    elseif zone == "Sengende Schlucht" then
        t["Defekter Kriegsgolem"] = true
        t["Hochlord Mastrogonde"] = true
        t["Rekk'tilac"] = true
        t["Scald"] = true
        t["Shleipnarr"] = true
        t["Sklavenmeister Blackheart"] = true
        t["Smoldar"] = true
        t["Das Ungetüm"] = true

    elseif zone == "Burg Shadowfang" then
        t["Todeshöriger Captain"] = true

    elseif zone == "Silithus" then
        t["Gretheer"] = true
        t["Grubthor"] = true
        t["Hurrikanus"] = true
        t["Krellack"] = true
        t["Lapress"] = true
        t["Rex Ashil"] = true
        t["Setis"] = true
        t["Twilight-Lord Everun"] = true
        t["Zora"] = true

    elseif zone == "Silberwald" then
        t["Zauberschreiber von Dalaran"] = true
        t["Blutmaul"] = true
        t["Krethis Shadowspinner"] = true
        t["Zwingenkiefer"] = true
        t["Regent von Rabenklaue"] = true
        t["Haudrauf der Moderfelle"] = true
        t["Knurrmähne"] = true
        t["Sohn von Arugal"] = true

    elseif zone == " Steinkrallengebirge" then
        t["Bruder Ravenoak"] = true
        t["Großknecht Rigger"] = true
        t["Nal'taszar"] = true
        t["Prachtschwingenpatriarch"] = true
        t["Schildwache Amarassan"] = true
        t["Schwester Sichelschwinge"] = true
        t["Trauerschwinge"] = true
        t["Zuchtmeister Whipfang"] = true
        t["Rachsüchtiges Urtum"] = true

    elseif zone == "Stormwind" then
        -- t["Sewer Beast"] = true        
        t["Elitewache von Onyxia"] = true

    elseif zone == "Schlingendorntal" then
        t["Gluckser"] = true
        t["Kurmokk"] = true
        t["Lord Sakrasis"] = true
        t["Schlächter der Mosh'Ogg"] = true
        t["Rippa"] = true
        t["Roloch"] = true
        t["Schuppenbauch"] = true
        t["Scarshield Quartermaster"] = true
        t["Verifonix"] = true

    elseif zone == "Stratholme" then
        t["Herdsinger Forresten"] = true
        t["Skul"] = true
        t["Steinbuckel"] = true
        t["Timmy der Grausame"] = true

    elseif zone == "Sümpfe des Elends" then
        t["Flossgat"] = true
        t["Kiemorius"] = true
        t["Jade"] = true
        t["Lord Captain Wyrmak"] = true
        t["Häuptling der Verirrten"] = true
        t["Koch der Verirrten"] = true
        t["Moosbart"] = true
        t["Zekkis"] = true

    elseif zone == "Tanaris" then
        t["Knochenhexe"] = true
        t["Cyclok der Irre"] = true
        t["Großer Feuervogel"] = true
        t["Haarka der Gefräßige"] = true
        t["Jin'Zallah der Sandbringer"] = true
        t["Kregg Kielhol"] = true
        t["Mordlustige Eiterpfote"] = true
        t["Omgorn der Verirrte"] = true
        t["Soriid der Verschlinger"] = true
        t["Geist der Verdammten"] = true
        t["Kriegsanführer Krazzilak"] = true

    elseif zone == "Teldrassil" then
        t["Schwarzmoos der Stinker"] = true
        t["Dämmerpirscher"] = true
        t["Furie Shelda"] = true
        t["Grimmtatze"] = true
        t["Threggil"] = true
        t["Uruson"] = true

    elseif zone == "Der Tempel von Atal'Hakkar" then
        t["Veyzhack der Kannibale"] = true

    elseif zone == "Brachland" then
        t["Aean Swiftriver"] = true
        t["Botschafter Blutzorn"] = true
        t["Azzere die Himmelsklinge"] = true
        t["Boahn"] = true
        t["Bruchspeer"] = true
        t["Brontus"] = true
        t["Captain Gerogg Hammerzeh"] = true
        t["Buddler Flammenschmied"] = true
        t["Dishu"] = true
        t["Alte Mystikerin Grimmschnauze"] = true
        t["Ingenieur Whirleygig"] = true
        t["Großknecht Grills"] = true
        t["Geopriester Gukk'rok"] = true
        t["Gesharahan"] = true
        t["Hagg Taurenbane"] = true
        t["Hannah Bladeleaf"] = true
        t["Heggin Steinbart"] = true
        t["Humar der Stolze Lord"] = true
        t["Malgin Gerstenbräu"] = true
        t["Marcus Bel"] = true
        t["Rathorian"] = true
        t["Felslanze"] = true
        t["Silithidernter"] = true
        t["Schwester Wildkralle"] = true
        t["Schlammbestie"] = true
        t["Snort der Spotter"] = true
        t["Steinarm"] = true
        t["Flinkmähne"] = true
        t["Swinegart-Speerbalg"] = true
        t["Takk der Springer"] = true
        t["Thora Feathermoon"] = true
        t["Donnerstampfer"] = true
        t["Zebrian the Mad"] = true

    elseif zone == "Die Todesminen" then
        t["Minenarbeiter Johnson"] = true

    elseif zone == "Hinterland" then
        t["Grimungous"] = true
        t["Eisenpanzer"] = true
        t["Jalinde Sommerdrache"] = true
        t["Mith'rethis der Verzauberer"] = true
        t["Klippenspringer"] = true
        t["Reißerklaue"] = true
        t["Retherokk der Berserker"] = true
        t["Der Reak"] = true
        t["Kaltherz der Streicher"] = true
        t["Zul'arek Faulhass"] = true

    elseif zone == "Das Verlies" then
        t["Bruegal Eisenfaust"] = true

    elseif zone == "Tausend Nadeln" then
        t["Achellios der Verbannte"] = true
        t["Gibblesnik"] = true
        t["Harb Faulberg"] = true
        t["Klingenherz"] = true
        t["Eisenauge der Unbesiegbare"] = true
        t["Silithidverheerer"] = true
        t["Stahlbiss"] = true
        t["Rok'Alim der Trommler"] = true
        t["Übelstich"] = true

    elseif zone == "Thunder Bluff" then
        t["Geistheuler"] = true

    elseif zone == "Tirisfal" then
        t["Bayne"] = true
        t["Deeb"] = true
        t["Gefallener Held"] = true
        t["Bauer Solliden"] = true
        t["Fellicents Schemen"] = true
        t["Verirrte Seele"] = true
        t["Muad"] = true
        t["Ressan der Aufstachler"] = true
        t["Sri'skulk"] = true
        t["Gepeinigter Geist"] = true

    elseif zone == "Un'Goro-Krater" then
        t["Baron Glutarr"] = true
        t["Gelegemutter Zavas"] = true
        t["Gruff"] = true
        t["König Mosh"] = true
        t["Ravasaurus-Matriarchin"] = true
        t["Uhk'loc"] = true
        t["Teufelssaurier"] = true
        t["Tyrannoteufelssaurier"] = true

    elseif zone == "Die Höhlen des Wehklagens" then
        t["Deviatfeendrache"] = true
        t["Trigore der Peitscher"] = true

    elseif zone == "Westliche Pestländer" then
        t["Gefallener Held"] = true
        t["Großknecht Jerris"] = true
        t["Großknecht Marcrid"] = true
        t["Faulmähne"] = true
        t["Lord Maldazzar"] = true
        t["Putridius"] = true
        t["Scharlachroter Henker"] = true
        t["Scharlachroter Hochkleriker"] = true
        t["Scharlachroter Befrager"] = true
        t["Scharlachroter Richter"] = true
        t["Scharlachroter Schmied"] = true
        t["Die Hülse"] = true

    elseif zone == "Westfall" then
        t["Brack"] = true
        t["Manipulierter Adliger"] = true
        t["Carver Molsen"] = true
        t["Feindschnitter 4000"] = true
        t["Leprithus"] = true
        t["Marisa du'Paige"] = true
        t["Meisterbuddler"] = true
        t["Sergeant Geiferkralle"] = true
        t["Slark"] = true
        t["Vultros"] = true

    elseif zone == "Sumpfland" then
        t["Kampfmeister der Dragonmaw"] = true
        t["Garneg Brandschädel"] = true
        t["Knochennager"] = true
        t["Egelwitwe"] = true
        t["Ma'ruk Wyrmschuppe"] = true
        t["Brülmor"] = true
        t["Scharfzahnmatriarchin"] = true
        t["Schlicker"] = true

    elseif zone == "Winterspring" then
        t["Azurous"] = true
        t["Knochenhexe"] = true
        t["General Colbatann"] = true
        t["Grizzel Schneepfote"] = true
        t["Kashoch der Häscher"] = true
        t["Lady Hederine"] = true
        t["Mezzir der Heuler"] = true
        t["Rak'shiri"] = true
        t["Geist der Verdammten"] = true

    elseif zone == "Zul'Farrak" then
        t["Karaburan"] = true
        t["Sandarr der Wüstenräuber"] = true
        t["Zerillis"] = true

    end
end
