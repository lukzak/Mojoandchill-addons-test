BINDING_HEADER_AUX = "aux";

local post = require 'aux.tabs.post'

function post_auctions_bind()
	post.post_auctions_bind()
end