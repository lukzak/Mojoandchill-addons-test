### Description
The addon will show a warning in the quest detail window if the quest has potential to [flag yourself for pvp](https://forum.turtle-wow.org/viewtopic.php?f=37&t=4490) or if it's a [dangerous quest](https://forum.turtle-wow.org/viewtopic.php?p=39294). Mouseover the warning to show the information for the quest.
