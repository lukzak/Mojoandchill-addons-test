# pfUI-TurtleMounts
Dismount Module by [Gurky-Kronos](https://github.com/Gurky-Kronos/-PFUI-TurtleWoW-Unmount-Module) for [pfUI](https://github.com/shagu/pfUI) to use on the custom Vanilla WoW Private Server [Turtle WoW](https://turtle-wow.org/).


## Installation 
1. Download **[Latest Version](https://github.com/mrrosh/pfUI-TurtleMounts/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-TurtleMounts-master" to "pfUI-TurtleMounts"
4. Copy "pfUI-TurtleMounts" into Wow-Directory\Interface\AddOns
5. Restart Wow
