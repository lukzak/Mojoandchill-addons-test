# PvPWarning
WoW 1.12 addon. Warns you when you get PvP flagged.

![PvP Warning](https://github.com/Lexiebean/PvPWarning/raw/main/Preview.png)

Made on request for Behappycat.
