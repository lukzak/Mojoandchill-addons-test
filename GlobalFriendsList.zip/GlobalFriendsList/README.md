# Global Friends List
A Vanilla Warcraft (1.12.1) addon that can carry your friends list between toons.

If a player deletes their toon while you are offline, Global Friends List will tell you the name of that player and will attempt to re-add them. For example, when a Hardcore player dies and deletes.

`/gfl global` - Toggle global mode on/off

When global mode is turned on for that toon, that toon will have access to your Global Friends List.
**THIS SETTING IS OFF BY DEFAULT AND WILL NEED TO BE TURNED ON FOR EACH TOON**
